<?php

namespace XT\Membermap\XF\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

class UserGroup extends XFCP_UserGroup
{

}