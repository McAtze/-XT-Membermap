<?php

namespace XT\Membermap\XF\Admin\Controller;

use XF\Mvc\ParameterBag;

class Tools extends XFCP_Tools
{
    public function actionGoogleApiCheck()
    {

    }

    public function actionBatchUpdateUser()
    {
        
    }
}