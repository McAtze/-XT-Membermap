<?php

namespace XT\Membermap\Service;

use Exception;
use XF\Mvc\Entity\Entity;
use XF\Service\AbstractService;
use XF\Util\Arr;

class GoogleApi extends AbstractService
{
    protected $apiKey = null;

    private $avaiable = null;

    protected function setup()
    {
        $this->apiKey = \XF::options()->xtMMGoogleMapsApiKey;
    }

    private function getApiKey()
    {
        return $this->apiKey;
    }

    public function fetchLocationData($userId, $location)
    {
        $apiUrl = 'https://maps.google.com/maps/api/geocode/json?address=' . urlencode($location) . '&key=' . $this->getApiKey();

        /**
         * @var \GuzzleHttp\Client $client
         */
        $client = \XF::app()->http()->client();
        $geocodeResponse = $client->get($apiUrl)->getBody();
        $geocodeData = \GuzzleHttp\json_decode($geocodeResponse);

        /**
         * Create LogData
         */
        $logData = [
            'user_id' => $userId,
            'request_url' => $apiUrl,
            'request_status' => $geocodeData->status,
            'request_data' => $geocodeData->results,
        ];

        $requestLog = $this->em()->create('XT\Membermap:Log');
        $requestLog->bulkSet($logData);
        $requestLog->save();

        if (
            !empty($geocodeData)
            && $geocodeData->status == 'OK'
            && isset($geocodeData->results)
            && isset($geocodeData->results[0])
        ) {
            return [
                'latitude' => $geocodeData->results[0]->geometry->location->lat,
                'longitude' => $geocodeData->results[0]->geometry->location->lng
            ];
        }
    }


    /**
     * @deprecated use User Entity function instead
     */
    public function getStaticLocationImageUser(\XF\Entity\User $user)
    {
        // try to find a saved image
        $minimapUrl = $user->getMinimapUrl();
        $minimapPath = $user->getAbstractedMinimapPath();

        if (!\XF\Util\File::abstractedPathExists($minimapPath))
        {
            $image = $this->fetchStaticLocationImageUser($user->Profile, $user->getMapMarkerIconPath());
            if (!\XF\Util\File::copyFileToAbstractedPath($image, $minimapPath))
            {
                $minimapUrl = false;
            }
        }

        return $minimapUrl;
    }

    /**
     * @param \XF\Entity\User $user
     * @return binary image;
     */
    public function fetchStaticLocationImageUser(\XF\Entity\UserProfile $profile, string $icon = '')
    {
        $imgPath = 'https://maps.googleapis.com/maps/api/staticmap';
        $imgParams = [
            'zoom' => 13,
            'size' => '228x228',
            'markers' => $this->markerBuilder($profile->xt_mm_location_lat, $profile->xt_mm_location_long, $icon),
            'key' => $this->getApiKey(),
        ];
        $apiUrl =  $imgPath .'?'. http_build_query($imgParams);

        /**
         * Create LogData
         */
        $logData = [
            'user_id' => $profile->user_id,
            'request_url' => $apiUrl,
            'request_status' => (!empty($apiUrl) ? 'OK' : 'Error'),
            'request_data' => [],
        ];

        $requestLog = $this->em()->create('XT\Membermap:Log');
        $requestLog->bulkSet($logData);
        $requestLog->save();

        return $apiUrl;
    }

    private function markerBuilder($lat, $long, $icon)
    {
        if (!empty($icon))
        {
            $marker = 'icon:' . $icon;
        }
        else
        {
            $marker = 'color:red';
        }
        $marker .= '|' . $lat . ',' . $long;
        
        return $marker;
    }
    /**
     * @param $apiKey String if a new key should be checked
     * @return Bool is ApiKey works
     */
    public function isAvaiable($testKey = false)
    {
        if ($testKey)
        {
            $url = 'https://maps.google.com/maps/api/geocode/json?address=Berlin&key=' . $testKey;
            /**
             * @var \GuzzleHttp\Client $client
             */
            $client = \XF::app()->http()->client();
            $response = $client->get($url)->getBody();
            $jsonResponse = \GuzzleHttp\json_decode($response);
            if ($jsonResponse->status == 'OK')
            {
                return true;
            }
            return false;
        }
        else
        {
            return !empty($this->getApiKey());
        }
       
    }
}


